export identityDomain=identity.us-ashburn-1.oraclecloud.com
export coreServicesDomain=iaas.us-ashburn-1.oraclecloud.com
export databaseServicesDomain=database.us-ashburn-1.oraclecloud.com
        
export tenancyId=ocid1.tenancy.oc1..aaaaaaaa7gup442a6kvo27atbfnlnjpws7lf7xsc3ig3wu7wc7zdig4wclra
export compartmentId=ocid1.compartment.oc1..aaaaaaaa4ddg3x2eqqi2jifg7wkpyc6eckg3ddgmipyilk7tynszqgq3a6aq
export apiUserId=ocid1.user.oc1..aaaaaaaapgr7xhmjhyb7k7zqpvmbn6pseoaw3o77pucuyef6jbrtw7aswgqa
export publicKeyFingerprint=9e:29:39:59:2b:b1:c9:4f:b5:b5:fa:05:5d:81:ae:1c
export pathToKey=./ssh/id_rsa_pri.pem