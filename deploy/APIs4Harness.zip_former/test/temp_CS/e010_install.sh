#!/bin/bash
#deploy kube application environments :: dashboard, monitoring, & metrics
  echo " " >>/tmp/tf-debug.log
  echo "e010_install.sh (dashmonmet) -->>" >>/tmp/tf-debug.log
  echo " " >>/tmp/tf-debug.log
#vars..
#assign args to vars..
  for ARGUMENT in "$@"; do
      KEY=$(echo $ARGUMENT | cut -f1 -d=)
      VALUE=$(echo $ARGUMENT | cut -f2 -d=)
          case "$KEY" in
              e009_tfApply)     e009_tfApply=${VALUE} ;;
              e010_DashMonMet)  e010_DashMonMet=${VALUE} ;;
              *)
          esac
  done
#define local vars..
  TIMEOUT="250"
#debug args..
  echo "e009_tfApply" = $e009_tfApply >>/tmp/tf-debug.log
  echo "e010_DashMonMet" = $e010_DashMonMet >>/tmp/tf-debug.log
#debug local vars..
#functions..
  #evaluate pod status..
  function kubectl::get_pod {
      local counter=0
      local status=""
          for ((counter=0; counter < ${TIMEOUT}; counter++)); do
                  status=$(kubectl --kubeconfig=${KUBECONFIG} get pod -n $1 | awk '{print $3}' | sort -u | head -n1)
                  if [ "${status}" = "Running" ]; then
                          echo "K8S-DEMO :: ENV-010 :: All '"$1"' pods running ..."
                          break
                  else
                      sleep 5
                  fi
          done
  }
#dashboards..
  #weavescope..
    if [[ $e009_tfApply = "true" ]]; then
        echo "K8S-DEMO :: ENV-010 :: Installing WeaveScope Dashboard ..."
        kubectl create -f /tmp/k8sdemo_env/e010_DashMonMet/scope-complete-demo_pri.yaml >>/tmp/tf-debug.log
        echo "K8S-DEMO :: ENV-010 :: Waiting for 'weave' pods (scope agent & app) to be up and running ..."
        kubectl::get_pod weave
        echo "K8S-DEMO :: ENV-010 :: Installing WeaveScope Dashboard ... :: Done ..."
    fi
