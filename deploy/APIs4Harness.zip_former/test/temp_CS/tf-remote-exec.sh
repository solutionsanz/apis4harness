#!/bin/bash
#deploy kube application environments
logger *** TF Apply :: Remote-Exec Started ***
  echo " " >>/tmp/tf-debug.log
  echo "remote_exec.sh -->>" >>/tmp/tf-debug.log
  echo " " >>/tmp/tf-debug.log
#vars..
#assign args to vars..
  for ARGUMENT in "$@"; do
      KEY=$(echo $ARGUMENT | cut -f1 -d=)
      VALUE=$(echo $ARGUMENT | cut -f2 -d=)
          case "$KEY" in
              c001_userOcid)    c001_userOcid=${VALUE} ;;
              e009_tfApply)     e009_tfApply=${VALUE} ;;
              e010_DashMonMet)  e010_DashMonMet=${VALUE} ;;
              e011_MicroSvc)    e011_MicroSvc=${VALUE} ;;
              e012_Faas)        e012_Faas=${VALUE} ;;
              e013_Ingress)     e013_Ingress=${VALUE} ;;
              e014_SvcMesh)     e014_SvcMesh=${VALUE} ;;
              *)
          esac
  done
#define local vars..
  e020_doHelm="${e012_Faas},${e014_SvcMesh}"
#debug args..
  echo "c001_userOcid" = $c001_userOcid >>/tmp/tf-debug.log
  echo "e009_tfApply" = $e009_tfApply >>/tmp/tf-debug.log
  echo "e010_DashMonMet" = $e010_DashMonMet >>/tmp/tf-debug.log
  echo "e011_MicroSvc" = $e011_MicroSvc >>/tmp/tf-debug.log
  echo "e012_Faas" = $e012_Faas >>/tmp/tf-debug.log
  echo "e013_Ingress" = $e013_Ingress >>/tmp/tf-debug.log
  echo "e014_SvcMesh" = $e014_SvcMesh >>/tmp/tf-debug.log
#debug local vars..
  echo "e020_doHelm" = $e020_doHelm >>/tmp/tf-debug.log
#let's get going..
  echo "K8S-DEMO :: Remote-Exec :: Let's get started ..."
  #general configuration..
      if [ $e009_tfApply = "true" ]; then
          echo "K8S-DEMO :: Remote-Exec :: Configure Files ..."
              find /tmp/k8sdemo_env/ -name '*.sh' -type f | xargs chmod +x
              #setup kubectl
              mkdir $HOME/.kube
              cp /tmp/k8sdemo_cfg/kubeconfig $HOME/.kube
              chown $(id -u):$(id -g) $HOME/.kube/kubeconfig
              export KUBECONFIG=$HOME/.kube/kubeconfig
              echo 'export KUBECONFIG=$HOME/.kube/kubeconfig' >> $HOME/.bashrc
          echo "K8S-DEMO :: Remote-Exec :: Configure Files ... :: Done ..."
          echo "K8S-DEMO :: Remote-Exec :: Configure K8s ..."
              #rbac..
              kubectl create clusterrolebinding owner-cluster-admin-binding --clusterrole cluster-admin --user=$c001_userOcid >>/tmp/tf-debug.log
          echo "K8S-DEMO :: Remote-Exec :: Configure K8S ... :: Done ..."
      fi
  #environment configuration..
      echo "K8S-DEMO :: Remote-Exec :: Configure Environments ..."
          #utils..
              if [ $e009_tfApply = "true" ]; then
                  echo "K8S-DEMO :: ENV-000 :: Configuring Tools & Utilities ..."
                  /tmp/k8sdemo_env/e000_Utils/e000_install.sh e020_doHelm=$e020_doHelm
                  echo "K8S-DEMO :: ENV-000 :: Configuring Tools & Utilities ... :: Done ..."
              fi
          #dashboard, monitoring, metrics..
              if [[ $e010_DashMonMet =~ .*true.* ]]; then
                  echo "K8S-DEMO :: ENV-010 :: Configuring Dashboards, Monitoring, Metrics ..."
                  /tmp/k8sdemo_env/e010_DashMonMet/e010_install.sh e009_tfApply=$e009_tfApply e010_DashMonMet=$e010_DashMonMet
                  echo "K8S-DEMO :: ENV-010 :: Configuring Dashboards, Monitoring, Metrics ... :: Done ..."
              fi
          #microservices..
              if [[ $e011_MicroSvc =~ .*true.* ]]; then
                  echo "K8S-DEMO :: ENV-011 :: Configuring Microservices Environment ..."
                   /tmp/k8sdemo_env/e011_MicroSvc/e011_install.sh e009_tfApply=$e009_tfApply e011_MicroSvc=$e011_MicroSvc
                  echo "K8S-DEMO :: ENV-011 :: Configuring Microservices Environment ... :: Done ..."
              fi
          #faas..
              if [[ $e012_Faas =~ .*true.* ]]; then
                  echo "K8S-DEMO :: ENV-012 :: Configuring FaaS Environment ..."
                   /tmp/k8sdemo_env/e012_Faas/e012_install.sh e009_tfApply=$e009_tfApply e012_Faas=$e012_Faas
                  echo "K8S-DEMO :: ENV-012 :: Configuring FaaS Environment ... :: Done ..."
              fi
          #ingress..
              if [[ $e013_Ingress =~ .*true.* ]]; then
                  echo "K8S-DEMO :: ENV-013 :: Configuring Ingress Environment ..."
                  /tmp/k8sdemo_env/e013_Ingress/e013_install.sh e009_tfApply=$e009_tfApply e013_Ingress=$e013_Ingress
                  echo "K8S-DEMO :: ENV-013 :: Configuring Ingress Environment ... :: Done ..."
              fi
          #service mesh..
              if [[ $e014_SvcMesh =~ .*true.* ]]; then
                  echo "K8S-DEMO :: ENV-014 :: Configuring Service Mesh Environment ..."
                  /tmp/k8sdemo_env/e014_SvcMesh/e014_install.sh e009_tfApply=$e009_tfApply e014_SvcMesh=$e014_SvcMesh
                  echo "K8S-DEMO :: ENV-014 :: Configuring Service Mesh Environment ... :: Done ..."
              fi
    if [ $e009_tfApply = "true" ]; then
        echo "K8S-DEMO :: Remote-Exec :: Configure Environments ... :: Done ..."
        echo " "
        echo "K8S-DEMO :: Remote-Exec :: List all services ..."
        echo "----------------------------------------------------------------------------------------"
        kubectl get services --all-namespaces
        echo " "
        echo "K8S-DEMO :: Remote-Exec :: List all pods ..."
        echo "----------------------------------------------------------------------------------------"
        kubectl get pods --all-namespaces
    fi
  echo " "
  echo "K8S-DEMO :: Remote-Exec :: Done ..."
logger *** TF Remote-Exec Stopped ***
